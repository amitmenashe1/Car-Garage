package enums;

public enum eEnergy
{
    Fuel,
    Battery
}
