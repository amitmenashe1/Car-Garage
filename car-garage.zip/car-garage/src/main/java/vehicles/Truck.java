package vehicles;
import enums.eEnergy;

public class Truck extends Vehicle
{
    public Truck(String i_ModelName, float[] i_currentWheelsPressure, float i_currentEnergyLevel)
    {
        super(i_ModelName, eEnergy.Fuel, 50, 16, i_currentWheelsPressure, i_currentEnergyLevel);
    }
}
