package vehicles;

import enums.eEnergy;

public class Car extends Vehicle
{
    public Car(String i_ModelName, eEnergy i_EnergySource, float[] i_currentWheelsPressure, float i_currentEnergyLevel)
    {
        super(i_ModelName, i_EnergySource, 35, 4, i_currentWheelsPressure, i_currentEnergyLevel);
    }
}
