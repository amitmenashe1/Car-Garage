package vehicles;
import enums.eEnergy;

public class Motorcycle extends Vehicle
{
    public Motorcycle(String i_ModelName, eEnergy i_EnergySource, float[] i_currentWheelsPressure, float i_currentEnergyLevel)
    {
        super(i_ModelName, i_EnergySource, 20, 2, i_currentWheelsPressure, i_currentEnergyLevel);
    }
}
